@echo off
setlocal EnableDelayedExpansion
title BILLY WATER - Gerador de Licencas

set "ROOT_DIR=%~dp0"
if "%ROOT_DIR:~-1%"=="\" set "ROOT_DIR=%ROOT_DIR:~0,-1%"

chcp 65001 >nul 2>&1
color 0F

echo ========================================================
echo   BILLY WATER - Gerador de Licencas (sistema separado)
echo ========================================================
echo.

:: ---- 1. Procurar Java (17 / 21 / 25) ----
set "JAVA_EXE="
if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
)
if not defined JAVA_EXE (
    for %%d in (
        "C:\Program Files\Eclipse Adoptium\jdk-25.0.3.9-hotspot"
        "C:\Program Files\Eclipse Adoptium\jdk-21.0.2.13-hotspot"
        "C:\Program Files\Eclipse Adoptium\jdk-21"
        "C:\Program Files\Eclipse Adoptium\jdk-25"
        "C:\Program Files\Java\jdk-21"
        "C:\Program Files\Java\jdk-17"
        "C:\Program Files\Java\jdk-25"
        "C:\Program Files\BellSoft\LibericaJDK-21"
        "C:\Program Files\Amazon Corretto\jdk21"
    ) do (
        if exist "%%~d\bin\java.exe" (
            set "JAVA_HOME=%%~d"
            set "JAVA_EXE=%%~d\bin\java.exe"
            goto :java_found
        )
    )
)
:java_found
if not defined JAVA_EXE (
    where java >nul 2>&1 && set "JAVA_EXE=java"
)
if not defined JAVA_EXE (
    echo [ERRO] Java 17 ou superior nao encontrado.
    echo        Instale o Eclipse Adoptium Temurin JDK 21: https://adoptium.net/
    echo.
    pause
    exit /b 1
)
echo  [OK] Java: %JAVA_EXE%

:: ---- 2. Maven ----
where mvn >nul 2>&1
if not !ERRORLEVEL! equ 0 (
    echo [ERRO] Maven nao encontrado no PATH.
    echo        Instale o Apache Maven : https://maven.apache.org/
    pause
    exit /b 1
)

cd /d "%ROOT_DIR%"
if not exist "%ROOT_DIR%\pom.xml" (
    echo [ERRO] pom.xml nao encontrado em: %ROOT_DIR%
    pause
    exit /b 1
)

echo [INFO] A compilar o gerador...
call mvn -B -q clean package
if not !ERRORLEVEL! equ 0 (
    echo.
    echo [ERRO] A compilacao falhou. Reveja as mensagens acima.
    pause
    exit /b 1
)

set "JAR=%ROOT_DIR%\target\gerador-licencas-5.0.0.jar"
if not exist "%JAR%" (
    echo [ERRO] Nao encontrei o jar em: %JAR%
    pause
    exit /b 1
)

echo.
echo [OK] Gerador pronto.
echo ========================================================
echo   GERAR LICENCA
echo   Uso:  GERAR-LICENCA "Titular" "NUIT" "DataExpira" "Dispositivos"
echo         (DataExpira: AAAA-MM-DD, ou 1y / 2y / 6m / 30d)
echo ========================================================
echo.

set /p TITULAR="Titular  : "
if "%TITULAR%"=="" set "TITULAR=DEMO BILLY WATER"
set /p NUIT="NUIT     : "
if "%NUIT%"=="" set "NUIT=100000000"
set /p EXPIRA="Expira   : "
if "%EXPIRA%"=="" set "EXPIRA=1y"
set /p DISP="Disposit.: "
if "%DISP%"=="" set "DISP=3"

echo.
echo A gerar licenca para: "%TITULAR%" ...
echo.
"%JAVA_EXE%" -jar "%JAR%" "%TITULAR%" "%NUIT%" "%EXPIRA%" "%DISP%"
echo.
set /p SAIDA="Ficheiro de saida (.lic) [ENTER=licenca_...lic]: "
if "%SAIDA%"=="" set "SAIDA=licenca_%TITULAR%.lic"
"%JAVA_EXE%" -jar "%JAR%" "%TITULAR%" "%NUIT%" "%EXPIRA%" "%DISP%" "%SAIDA%"

echo.
echo Licenca gerada. Pode ser activada no BILLY WATER em:
echo   Configuracoes - Licenca - Activar licenca (.lic)
echo.
echo Tambem pode gerar um NOVO PAR de chaves com GERAR-CHAVES.bat
echo (invalida todas as licencas antigas; reembeba a publica no SGF).
echo.
pause
endlocal
