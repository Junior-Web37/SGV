# BILLY WATER — Instalar / Usar (standalone, 2 cliques)

Este é o **BILLY WATER (SGF)** sozinho — sem nada do SGV. É um projecto Maven/JavaFX
autónomo: o `pom.xml` está na raiz desta pasta.

---

## 🚀 Opção A — Descarregar o instalador pronto (o mais simples)

1. Na página **Releases** deste repositório, descarrega o **`billywater-5.0.0.msi`**
   (instalador) ou o **`billywater-5.0.0.zip`** (portátil).
2. Duplo clique no `.msi` para instalar (ou descompacta o `.zip`).
3. Duplo clique no atalho **BILLY WATER** que fica no Ambiente de Trabalho.

> ⚠️ Este instalador é gerado pelo **GitHub Actions** (workflow `.github/workflows/build.yml`).
> Se ainda não houver Release, usa a Opção B.

---

## 🔧 Opção B — Clonar/descompactar o código e correr

**Pré-requisitos** (uma vez): **JDK 17+** (Temurin: https://adoptium.net/) e **Apache Maven**
(https://maven.apache.org/).

Depois de descompactares a pasta:

1. Duplo clique em **`BILLY-WATER.bat`** — se não houver jar, o script chama o Maven e
   **compila/abre o sistema** automaticamente (a primeira vez demora a descarregar dependências).
   Arranca no perfil **TESTE** (base H2 local em `data/`), sem servidor de BD.
2. Para gerar o **instalador Windows**: duplo clique em **`COMPILAR-BILLY-WATER.bat`** →
   produz `target\billywater-5.0.0.msi` e `.zip`.
3. Para criar um **atalho no Ambiente de Trabalho**: duplo clique em **`ATALHO-BILLY-WATER.bat`**.

## Login

- **admin / admin123** (Administrador)
- Se não houver licença, a app entra em **modo demonstração** (aviso no arranque).

## Licença

- O SGF **verifica** a licença com a chave pública (`src/main/resources/licenca/publica.pem`).
- As licenças são **assinadas** pelo sistema separado **`gerador-licencas`** (contém a chave privada).
- Em *Configurações → Licença → Activar licença (.lic)* importas o `.lic`.

## Base de dados

- **Perfil TESTE (predefinição):** H2 local e cifrada em `data/billywater.mv.db` — zero configuração.
- **Perfil REAL (produção):** PostgreSQL. Edita `src/main/resources/config.properties` com
  `billywater.perfil=REAL` e os dados `real.bd.*`.
