@echo off
setlocal
title BILLY WATER - Diagnostico

set "ROOT_DIR=%~dp0"
if "%ROOT_DIR:~-1%"=="\" set "ROOT_DIR=%ROOT_DIR:~0,-1%"

color 0F

echo ========================================================
echo   BILLY WATER - DIAGNOSTICO (mostra todos os erros)
echo ========================================================
echo.

where mvn >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Maven nao encontrado no PATH.
    echo        Instale o Apache Maven : https://maven.apache.org/
    echo.
    pause
    goto :fim
)

echo [INFO] Java:
java -version 2>&1
echo.
echo [INFO] Maven:
mvn -version 2>&1
echo.

echo [INFO] A compilar e correr com Maven (em primeiro plano)...
echo        A janela pode demorar a abrir. Aqui vai aparecer qualquer erro.
echo.
cd /d "%ROOT_DIR%"
call mvn -f "%ROOT_DIR%\pom.xml" -DskipTests javafx:run

echo.
echo ========================================================
echo  O BILLY WATER fechou. Se nao abriu, reveja as mensagens
echo  acima. Erros comuns:
echo   - "JavaFX runtime components are missing" -> use Maven
echo   - Erro de base de dados -> ver config.properties
echo ========================================================
echo.
pause

:fim
endlocal
