# BILLY WATER — Gerador de Licenças (sistema separado)

Este é o **sistema independente de geração/assinatura de licenças** do SGF (BILLY WATER).
Ele é o **único** sistema que contém a **chave privada**. O SGF **apenas verifica** as
licenças com a **chave pública** embebida (`billywater/src/main/resources/licenca/publica.pem`).

> ⚠️ **Regra de segurança**: nunca coloque a chave privada (`chaves/privada.pem`) dentro do
> repositório/artefactos do SGF. A privada vive apenas aqui; o público é o único que viaja
> para o SGF.

---

## Arquitectura de licença

O ficheiro de licença é um simples texto `chave=valor` (um campo por linha). A assinatura
(`assinatura=...`, base64 de RSA-**SHA256**) cobre os campos na **ordem canónica**:

```
produto,versao,titular,nuit,emissao,expira,dispositivos
```

O SGF reconstrói exactamente o mesmo payload e verifica-o com a chave pública. Por isso a
validação é à prova de alterações de terceiros: qualquer alteração aos campos invalida a
assinatura.

Exemplo de licença:

```
# Licença BILLY WATER / SGF
produto=BILLY WATER
versao=5
titular=DEMO BILLY WATER
nuit=100000000
emissao=2026-08-31
expira=2027-08-31
dispositivos=3
assinatura=YZkK5HgzJ5uNsgGUbWIRLt9LYQJf66/4...
```

---

## O que contém esta pasta

| Ficheiro | Descrição |
|---|---|
| `src/main/java/com/billywater/licencas/GeradorChaves.java` | Gera um novo par RSA (privada+publica) e grava em `chaves/`. |
| `src/main/java/com/billywater/licencas/GeradorLicenca.java` | Assina uma licença com a chave privada e escreve o `.lic`. |
| `src/main/resources/chaves/privada.pem` | 🔑 Chave **privada** (segredo). |
| `src/main/resources/chaves/publica.pem` | Chave **pública** (a mesma que o SGF embebe). |
| `.github/workflows/build.yml` | CI: compila e gera o jar do gerador (não contém o SGF). |

---

## Requisitos

- JDK 17+
- Maven 3.8+

## Compilar

```bash
mvn clean package
```

Gera `target/gerador-licencas-5.0.0.jar` (executável/fat-jar, main `GeradorLicenca`).

---

## Como gerar/assinar uma licença

Basta correr o jar com os argumentos:

```bash
# Sintaxe: titular nuit expira dispositivos ficheiro
java -jar target/gerador-licencas-5.0.0.jar "Cliente Alpha SA" 123456789 2027-08-31 3 licenca_alpha.lic
```

Sem argumentos gera uma **licença de demonstração** (titular `DEMO`):

```bash
java -jar target/gerador-licencas-5.0.0.jar
# → licenca_DEMO_2027-08-31.lic
```

O campo `expira` aceita datas (`2027-08-31`) ou atalhos relativos a hoje:
`1y`, `2y`, `6m`, `30d`.

Também pode correr via Maven:

```bash
mvn -q exec:java -Dexec.args="Cliente Alpha SA 123456789 2027-08-31 3"
```

### Activar no SGF

1. Copie o ficheiro `.lic` para a máquina do SGF.
2. No SGF: **Configurações → Licença → Activar licença (.lic)**.

---

## Gerar um novo par de chaves

Só precisa disto se quiser **invalidar** todas as licenças antigas (por exemplo, porque a
privada foi comprometida):

```bash
java -cp target/gerador-licencas-5.0.0.jar com.billywater.licencas.GeradorChaves 3072
```

Isso reescreve `chaves/privada.pem` e `chaves/publica.pem`. Depois **re-embeba** a nova chave
pública no SGF (`billywater/src/main/resources/licenca/publica.pem`) e distribua novas licenças.
