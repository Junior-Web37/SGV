@echo off
setlocal EnableDelayedExpansion
title BILLY WATER - Gerador de Chaves RSA

set "ROOT_DIR=%~dp0"
if "%ROOT_DIR:~-1%"=="\" set "ROOT_DIR=%ROOT_DIR:~0,-1%"

chcp 65001 >nul 2>&1
color 0F

echo ========================================================
echo   BILLY WATER - Gerar NOVO PAR de chaves RSA
echo ========================================================
echo.
echo  ATENCAO: isto GERA novas chaves e INVALIDA todas as
echo  licencas antigas. Depois de gerar:
echo     1) Copie a NOVA publica.pem para o BILLY WATER
echo        (src\main\resources\licenca\publica.pem)
echo     2) Distribua NOVAS licencas com GERAR-LICENCA.bat
echo ========================================================
echo.

:: ---- 1. Procurar Java ----
set "JAVA_EXE="
if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
)
if not defined JAVA_EXE ( where java >nul 2>&1 && set "JAVA_EXE=java" )
if not defined JAVA_EXE (
    echo [ERRO] Java 17 ou superior nao encontrado.
    pause
    exit /b 1
)

cd /d "%ROOT_DIR%"
if not exist "%ROOT_DIR%\pom.xml" (
    echo [ERRO] pom.xml nao encontrado em: %ROOT_DIR%
    pause
    exit /b 1
)

echo [INFO] A compilar o gerador...
call mvn -B -q clean package
if not !ERRORLEVEL! equ 0 (
    echo [ERRO] A compilacao falhou.
    pause
    exit /b 1
)

set /p BITS="Tamanho da chave (2048/3072/4096) [ENTER=3072]: "
if "%BITS%"=="" set "BITS=3072"

echo.
echo A gerar par de chaves RSA-%BITS% ...
echo.
"%JAVA_EXE%" -cp "%ROOT_DIR%\target\gerador-licencas-5.0.0.jar" com.billywater.licencas.GeradorChaves %BITS%

echo.
echo Novo par de chaves gravado em: %ROOT_DIR%\src\main\resources\chaves\
echo   - privada.pem  (mantem-so aqui, NO SGV NUNCA)
echo   - publica.pem  (copie para o BILLY WATER)
echo.
pause
endlocal
