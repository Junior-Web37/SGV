@echo off
setlocal
title BILLY WATER - Compilador / Instalador Windows

set "ROOT_DIR=%~dp0"
if "%ROOT_DIR:~-1%"=="\" set "ROOT_DIR=%ROOT_DIR:~0,-1%"

color 0F

echo ========================================================
echo   BILLY WATER - Compilacao e Instalador Windows (MSI/ZIP)
echo ========================================================
echo  Requisitos: JDK 17+ e Maven.
echo.

where mvn >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Maven nao encontrado no PATH.
    echo        Instale o Apache Maven : https://maven.apache.org/
    echo        e o JDK 17+            : https://adoptium.net/
    echo.
    pause
    goto :fim
)

cd /d "%ROOT_DIR%"
if not exist "%ROOT_DIR%\pom.xml" (
    echo [ERRO] pom.xml nao encontrado em: %ROOT_DIR%
    echo.
    pause
    goto :fim
)

echo [1/2] A compilar fat-jar...
echo.
call mvn -B -q clean package
if errorlevel 1 (
    echo.
    echo [ERRO] A compilacao falhou. Reveja as mensagens acima.
    echo.
    pause
    goto :fim
)
echo.
echo [OK] Fat-jar gerado em: %ROOT_DIR%\target\billywater-5.0.0.jar

echo.
echo [2/2] A gerar instalador/portatil Windows (MSI + ZIP)...
echo         (pode demorar; requer JavaFX/Launcher no Windows)
echo.
call mvn -B -Pdist clean package -DskipTests
if errorlevel 1 (
    echo.
    echo [AVISO] O passo -Pdist falhou (comum fora de Windows ou sem JRE).
    echo         O fat-jar ja esta pronto em: target\billywater-5.0.0.jar
    echo         Pode iniciar o sistema clicando em BILLY-WATER.bat
    echo.
    pause
    goto :fim
)

echo.
echo [OK] Instalador/portatil gerado em: %ROOT_DIR%\target\
dir /b "%ROOT_DIR%\target\*.msi" "%ROOT_DIR%\target\*.zip" 2>nul
echo.
echo Para instalar: execute o ficheiro .msi (Windows) ou use o .zip portatil.
echo.
set /p INICIAR="Deseja iniciar o BILLY WATER agora? (S/N): "
if /i "%INICIAR%"=="S" (
    echo.
    echo A iniciar BILLY WATER...
    if exist "%ROOT_DIR%\BILLY-WATER.bat" (
        call "%ROOT_DIR%\BILLY-WATER.bat"
    ) else (
        start "" "%ROOT_DIR%\target\billywater-5.0.0.jar" 2>nul
        echo  (a janela do BILLY WATER devera abrir numa segunda janela)
    )
)
echo.
pause

:fim
endlocal
