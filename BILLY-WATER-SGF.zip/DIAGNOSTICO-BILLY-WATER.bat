@echo off
setlocal
title BILLY WATER - Diagnostico

set "ROOT_DIR=%~dp0"
if "%ROOT_DIR:~-1%"=="\" set "ROOT_DIR=%ROOT_DIR:~0,-1%"
set "LOG=%ROOT_DIR%\DIAGNOSTICO.log"

color 0F
cls

echo ========================================================
echo   BILLY WATER - DIAGNOSTICO  (grava tudo em DIAGNOSTICO.log)
echo ========================================================
echo.
echo    A janela pode fechar, mas o resultado fica em:
echo    %LOG%
echo.
echo    A decorrer, aguarde...
echo.

rem Limpa o log
> "%LOG%" echo BILLY WATER DIAGNOSTICO - %DATE% %TIME%
>> "%LOG%" echo ==============================================

rem Java e Maven
echo. >> "%LOG%"
echo [JAVA] >> "%LOG%"
java -version >> "%LOG%" 2>&1
echo. >> "%LOG%"
echo [MAVEN] >> "%LOG%"
mvn -version >> "%LOG%" 2>&1

rem Correr com Maven, a gravar no log
echo. >> "%LOG%"
echo [MVN javafx:run] >> "%LOG%"
cd /d "%ROOT_DIR%"
mvn -f "%ROOT_DIR%\pom.xml" -DskipTests javafx:run >> "%LOG%" 2>&1

echo. >> "%LOG%"
echo ==== FIM DO DIAGNOSTICO ==== >> "%LOG%"

echo.
echo  ========================================================
echo   Terminado. Consulta o resultado no ficheiro:
echo     %LOG%
echo  ========================================================
echo.

rem Mostra as ultimas linhas do log
echo  Ultimas linhas:
echo  --------------------------------------------------
type "%LOG%"
echo  --------------------------------------------------
echo.

rem Espera (mesmo que feche, o log ja foi gravado)
pause
endlocal
