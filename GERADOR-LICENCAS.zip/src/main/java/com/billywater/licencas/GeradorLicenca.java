package com.billywater.licencas;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.LocalDate;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Gera/assina ficheiros de licença do SGF (BILLY WATER), usando a chave PRIVADA.
 *
 * <p>Este é o ÚNICO sistema com a chave privada. O SGF apenas VERIFICA com a chave pública.</p>
 *
 * <p>Formato do ficheiro gerado (um campo por linha):</p>
 * <pre>
 *   produto=BILLY WATER
 *   versao=5
 *   titular=Nome do cliente
 *   nuit=100000000
 *   emissao=2026-08-31
 *   expira=2027-08-31
 *   dispositivos=3
 *   assinatura=&lt;base64 RSA-SHA256&gt;
 * </pre>
 *
 * <p>A assinatura cobre a ordem canónica: produto,versao,titular,nuit,emissao,expira,dispositivos
 * — exactamente o mesmo payload que o SGF valida. Assim, o gerador e o verificador ficam em sincronia.</p>
 *
 * <p>Uso: {@code mvn -Pgerar exec:java} ou
 * {@code java -jar gerador-licencas-5.0.0.jar} com os seguintes argumentos:</p>
 * <pre>
 *   1. titular       Nome do titular (obrigatório)
 *   2. nuit          NUIT do titular (ex.: 100000000)
 *   3. expira        Data de expiração AAAA-MM-DD (ex.: 2027-08-31, ou "1y"/"2y" para anos a partir de hoje)
 *   4. dispositivos  Nº de dispositivos (ex.: 3)
 *   5. (opcional)    Ficheiro de saída (ex.: licenca.lic)  [padrão: licenca_&lt;titular&gt;.lic]
 * </pre>
 * Se não passar argumentos, gera uma licença de demonstração (titular "DEMO").
 */
public final class GeradorLicenca {

    private static final String PRODUTO = "BILLY WATER";
    private static final int VERSAO = 5;
    private static final String CANONICAIS = "produto,versao,titular,nuit,emissao,expira,dispositivos";

    private GeradorLicenca() {}

    public static void main(String[] args) throws Exception {
        String titular = args.length > 0 ? args[0] : "DEMO BILLY WATER";
        String nuit = args.length > 1 ? args[1] : "100000000";
        String expira = args.length > 2 ? args[2] : "1y";
        int dispositivos = args.length > 3 ? Integer.parseInt(args[3]) : 3;
        boolean demo = args.length == 0;

        LocalDate hoje = LocalDate.now();
        LocalDate emissao = hoje;
        String expiraNorm = normalizarExpira(expira, hoje);

        Map<String, String> campos = new LinkedHashMap<>();
        campos.put("produto", PRODUTO);
        campos.put("versao", Integer.toString(VERSAO));
        campos.put("titular", titular);
        campos.put("nuit", nuit);
        campos.put("emissao", emissao.toString());
        campos.put("expira", expiraNorm);
        campos.put("dispositivos", Integer.toString(dispositivos));

        String payload = payloadCanonico(campos);
        String assinatura = assinar(payload);

        StringBuilder lic = new StringBuilder();
        lic.append("# Licença BILLY WATER / SGF\n");
        if (demo) lic.append("# LICENÇA DE DEMONSTRAÇÃO — pode ser usada apenas em modo demo\n");
        lic.append("#\n");
        for (String k : CANONICAIS.split(",")) lic.append(k).append('=').append(campos.get(k)).append('\n');
        lic.append("assinatura=").append(assinatura).append('\n');

        Path out = args.length > 4
                ? Paths.get(args[4])
                : Paths.get("licenca_" + sanity(titular) + "_" + expiraNorm + ".lic");
        Files.writeString(out, lic.toString(), StandardCharsets.UTF_8);

        System.out.println("Licença assinada pelo sistema independente (chave privada).");
        System.out.println("  Ficheiro: " + out.toAbsolutePath());
        System.out.println("  Titular : " + titular + "  ·  NUIT: " + nuit);
        System.out.println("  Válida  : " + emissao + " → " + expiraNorm + "  ·  Dispositivos: " + dispositivos);
        System.out.println("  Assinatura (SHA256withRSA):\n    " + assinatura);
        System.out.println();
        System.out.println("A chave pública embebida no SGF deve ser este footprint:");
        System.out.println("  " + footprintPublica());
    }

    /** Constrói o payload canónico na mesma ordem usada pelo verificador do SGF. */
    static String payloadCanonico(Map<String, String> campos) {
        StringBuilder sb = new StringBuilder();
        for (String k : CANONICAIS.split(",")) {
            String v = campos.get(k);
            sb.append(k).append('=').append(v == null ? "" : v).append('\n');
        }
        return sb.toString();
    }

    /** Lê a chave privada dos recursos e assina o payload (RSA-SHA256). */
    static String assinar(String payload) throws Exception {
        byte[] der;
        try (InputStream in = GeradorLicenca.class.getResourceAsStream("/chaves/privada.pem")) {
            if (in == null) throw new IllegalStateException("Falta /chaves/privada.pem — gera primeiro com GeradorChaves.");
            String pem = new String(in.readAllBytes(), StandardCharsets.UTF_8)
                    .replace("-----BEGIN PRIVATE KEY-----", "")
                    .replace("-----END PRIVATE KEY-----", "")
                    .replaceAll("\\s", "");
            der = Base64.getDecoder().decode(pem);
        }
        PrivateKey priv = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(der));
        Signature sig = Signature.getInstance("SHA256withRSA");
        sig.initSign(priv);
        sig.update(payload.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(sig.sign());
    }

    static String normalizarExpira(String expira, LocalDate hoje) {
        String e = expira.trim().toLowerCase();
        try {
            if (e.endsWith("y")) return hoje.plusYears(Integer.parseInt(e.replace("y", ""))).toString();
            if (e.endsWith("m")) return hoje.plusMonths(Integer.parseInt(e.replace("m", ""))).toString();
            if (e.endsWith("d")) return hoje.plusDays(Integer.parseInt(e.replace("d", ""))).toString();
        } catch (NumberFormatException ignored) {}
        try { return LocalDate.parse(expira).toString(); } catch (Exception ex) { return hoje.plusYears(1).toString(); }
    }

    private static String sanity(String s) {
        return s.replaceAll("[^A-Za-z0-9._-]+", "_");
    }

    private static String footprintPublica() {
        try (InputStream in = GeradorLicenca.class.getResourceAsStream("/chaves/publica.pem")) {
            if (in == null) return "(não encontrada)";
            String pem = new String(in.readAllBytes(), StandardCharsets.UTF_8)
                    .replace("-----BEGIN PUBLIC KEY-----", "")
                    .replace("-----END PUBLIC KEY-----", "")
                    .replaceAll("\\s", "");
            byte[] der = Base64.getDecoder().decode(pem);
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(der);
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return "(erro)"; }
    }
}
