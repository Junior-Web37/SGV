@echo off
setlocal
title BILLY WATER - Sistema de Gestao de Facturacao de Agua

set "ROOT_DIR=%~dp0"
if "%ROOT_DIR:~-1%"=="\" set "ROOT_DIR=%ROOT_DIR:~0,-1%"

color 0F

echo ========================================================
echo   BILLY WATER - SGF (Sistema de Gestao de Facturacao)
echo ========================================================
echo.

rem ---- 1. Procurar Java (17 / 21 / 25) ----
set "JAVA_EXE="
if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
)
if not defined JAVA_EXE (
    for %%d in (
        "C:\Program Files\Eclipse Adoptium\jdk-25.0.3.9-hotspot"
        "C:\Program Files\Eclipse Adoptium\jdk-21.0.2.13-hotspot"
        "C:\Program Files\Eclipse Adoptium\jdk-21"
        "C:\Program Files\Eclipse Adoptium\jdk-25"
        "C:\Program Files\Java\jdk-21"
        "C:\Program Files\Java\jdk-17"
        "C:\Program Files\Java\jdk-25"
        "C:\Program Files\BellSoft\LibericaJDK-21"
        "C:\Program Files\Amazon Corretto\jdk21"
    ) do (
        if exist "%%~d\bin\java.exe" (
            set "JAVA_HOME=%%~d"
            set "JAVA_EXE=%%~d\bin\java.exe"
            goto :java_found
        )
    )
)
:java_found
if not defined JAVA_EXE (
    where java >nul 2>&1 && set "JAVA_EXE=java"
)
if not defined JAVA_EXE (
    echo [ERRO] Java 17 ou superior nao encontrado.
    echo        Instale o Eclipse Adoptium Temurin JDK 21: https://adoptium.net/
    echo.
    pause
    goto :fim
)
echo  [OK] Java: %JAVA_EXE%

rem ---- 2. Pastas de dados ----
if not exist "%ROOT_DIR%\data" mkdir "%ROOT_DIR%\data" >nul 2>&1
if not exist "%ROOT_DIR%\backups" mkdir "%ROOT_DIR%\backups" >nul 2>&1
if not exist "%ROOT_DIR%\config" mkdir "%ROOT_DIR%\config" >nul 2>&1

cd /d "%ROOT_DIR%"

rem ---- 3. Estrategia de arranque ----
rem  Se o fat-jar existir, corre directo (mais rapido). Senao usa mvn javafx:run.
set "JAR=%ROOT_DIR%\target\billywater-5.0.0.jar"

if exist "%JAR%" (
    echo  [OK] A iniciar BILLY WATER (jar de producao)...
    echo.
    "%JAVA_EXE%" -Dprism.order=sw -jar "%JAR%"
    echo.
    echo  O BILLY WATER fechou. Se nao abriu, corre DIAGNOSTICO-BILLY-WATER.bat.
    echo.
    pause
    goto :fim
)

rem ---- 4. Sem jar: precisa de Maven ----
where mvn >nul 2>&1
if errorlevel 1 (
    echo.
    echo [AVISO] Nao foi possivel iniciar automaticamente.
    echo        1) Instale o JDK 17+  : https://adoptium.net/
    echo        2) Instale o Maven   : https://maven.apache.org/
    echo        Depois execute:  COMPILAR-BILLY-WATER.bat
    echo.
    pause
    goto :fim
)

echo  [INFO] A compilar o fat-jar e iniciar pelo Maven...
echo         (a primeira vez demora a descarregar dependencias)
echo.
call mvn -f "%ROOT_DIR%\pom.xml" -DskipTests javafx:run
echo.
echo  O BILLY WATER fechou. Se nao abriu, corre DIAGNOSTICO-BILLY-WATER.bat
echo  para ver o erro exacto (grava em DIAGNOSTICO.log).
echo.
pause

:fim
endlocal
