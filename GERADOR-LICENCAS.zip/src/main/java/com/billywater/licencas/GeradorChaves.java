package com.billywater.licencas;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

/**
 * Gera um par de chaves RSA (adequadamente 2048 ou superior) e grava-as em
 * {@code src/main/resources/chaves/}.
 *
 * <p>A chave PÚBLICA é a que o SGF embebe (verificar); a chave PRIVADA permanece NESTE sistema.</p>
 *
 * <p>Uso: {@code mvn -Pgerar-chaves compile} ou executar directamente:
 * {@code java com.billywater.licencas.GeradorChaves}</p>
 */
public final class GeradorChaves {

    private GeradorChaves() {}

    public static void main(String[] args) throws Exception {
        int bits = 2048;
        if (args.length > 0) bits = Integer.parseInt(args[0]);
        KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
        gen.initialize(bits);
        KeyPair par = gen.generateKeyPair();

        Path dir = Paths.get("src/main/resources/chaves");
        Files.createDirectories(dir);

        Path priv = dir.resolve("privada.pem");
        Path pub = dir.resolve("publica.pem");
        Files.writeString(priv, privadaParaPem(par.getPrivate()), StandardCharsets.UTF_8);
        Files.writeString(pub, publicaParaPem(par.getPublic()), StandardCharsets.UTF_8);

        System.out.println("Par de chaves RSA-" + bits + " gerado e gravado em:");
        System.out.println("  " + priv.toAbsolutePath());
        System.out.println("  " + pub.toAbsolutePath());

        // Validar consistência da chave publica derivada da privada
        String pubDerivada = Base64.getEncoder().encodeToString(par.getPrivate().getEncoded());
        System.out.println("(verifique que o SGF embebe a chave pública: " + footprint(par.getPublic()) + ")");
    }

    static String privadaParaPem(PrivateKey k) {
        return "-----BEGIN PRIVATE KEY-----\n" + Base64.getMimeEncoder(64, "\n".getBytes(StandardCharsets.UTF_8)).encodeToString(k.getEncoded()) + "\n-----END PRIVATE KEY-----\n";
    }

    static String publicaParaPem(PublicKey k) {
        return "-----BEGIN PUBLIC KEY-----\n" + Base64.getMimeEncoder(64, "\n".getBytes(StandardCharsets.UTF_8)).encodeToString(k.getEncoded()) + "\n-----END PUBLIC KEY-----\n";
    }

    private static String footprint(PublicKey k) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(k.getEncoded());
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return "?"; }
    }
}
